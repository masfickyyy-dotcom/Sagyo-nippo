# 作業日報 Ninku PWA

## 機能
- ① 入力
- ② まとめ
- ③ 工程・設定
- 1人工 = 7時間
- 現場 / 作業者 / 工程 / 人数 / 作業時間 / 備考
- ローカル保存
- CSV出力
- PWA / Service Worker

## 公開方法（GitHub Pages）
1. GitHubで新しいRepositoryを作る。
2. このフォルダの中身をそのRepositoryのrootへアップロードする。
3. `main` にpushする。
4. GitHub → Settings → Pages → Source が `GitHub Actions` になっていることを確認。
5. Actionsの `Deploy 作業日報 to GitHub Pages` が成功するとURLが発行される。
6. iPhoneのSafariでそのURLを開く → 共有 → 「ホーム画面に追加」。

## 注意
ChatGPT内のファイルプレビューでは、JavaScript/PWAの動作が制限される場合があります。
実際のWeb URLで開くことで、①②③のタブとPWA機能を正常に利用できます。
